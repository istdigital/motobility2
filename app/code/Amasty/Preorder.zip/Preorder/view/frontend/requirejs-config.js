/*jshint browser:true jquery:true*/
/*global alert*/
var config = {
    config: {
        mixins: {
            'Magento_Catalog/js/catalog-add-to-cart': {
                'Amasty_Preorder/js/product/catalog-add-to-cart-mixin': true
            }
        }
    }
};
