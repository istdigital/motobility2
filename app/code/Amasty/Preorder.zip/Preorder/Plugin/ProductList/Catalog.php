<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2020 Amasty (https://www.amasty.com)
 * @package Amasty_Preorder
 */


namespace Amasty\Preorder\Plugin\ProductList;

class Catalog extends \Amasty\Preorder\Plugin\AbstractProductList
{

}
